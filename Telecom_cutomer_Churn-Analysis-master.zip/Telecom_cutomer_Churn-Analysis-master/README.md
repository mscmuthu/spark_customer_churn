# Telecom_cutomer_Churn-Analysis
I have used this Telecom Customer dataset to predict the churn with the Logistic regression, Decision Tree and Random Forest algorithm using Bigdata (Spark and Hive-Hbase)

# Customer churn prediction: Telecom Churn Dataset:

Customer churn, also known as customer retention, customer turnover, or customer defection, is the loss of clients or customers.

Telephone service companies, Internet service providers, pay TV companies, insurance firms, and alarm monitoring services, often use customer 
attrition analysis and customer attrition rates as one of their key business metrics because the cost of retaining an existing customer is far less than
 acquiring a new one. Companies from these sectors often have customer service branches which attempt to win back defecting clients, because 
recovered long-term customers can be worth much more to a company than newly recruited clients.

Companies usually make a distinction between voluntary churn and involuntary churn. Voluntary churn occurs due to a decision by the customer to 
switch to another company or service provider, involuntary churn occurs due to circumstances such as a customer's relocation to a long-term care facility,
 death, or the relocation to a distant location. In most applications, involuntary reasons for churn are excluded from the analytical models. Analysts 
tend to concentrate on voluntary churn, because it typically occurs due to factors of the company-customer relationship which companies control, 
such as how billing interactions are handled or how after-sales help is provided.
